const theme = {
  color: "#000035",
  bgColor: "#F4F1F5",
  gdLeft: "#475AC3",
  gdRight: "#8B55D0",
  sectionMargin: "5rem 8%"
};


export default theme;